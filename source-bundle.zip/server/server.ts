import http from 'node:http';
import {readFile,writeFile,mkdir,rm,stat} from 'node:fs/promises';
import {randomBytes,createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import path from 'node:path';
import {POST as search} from '../app/api/search/route';
import {GET as fulltext} from '../app/api/fulltext/route';
import {POST as synthesis} from '../app/api/synthesis/route';
import {protectPdfText,readTranslation} from '../lib/pdf-translation';

const root='/tmp/mizan', ttl=60*60*1000, jobs=new Map<string,Job>();
type Job={id:string;dir:string;created:number;status:string;progress:string;error?:string;action:string};
let active=false;const queue:{job:Job;run:()=>Promise<unknown>}[]=[];
await mkdir(root,{recursive:true});
function fail(message:string,status=400):never{throw Object.assign(new Error(message),{status})}
function json(value:unknown,status=200){return Response.json(value,{status,headers:{'Cache-Control':'no-store'}})}
async function python(job:Job,input:object){
 const inputFile=path.join(job.dir,'input.json');await writeFile(inputFile,JSON.stringify(input));
 return await new Promise<any>((resolve,reject)=>{
  const child=spawn('python',['engine/worker.py',inputFile],{stdio:['ignore','pipe','pipe'],env:{...process.env,OMP_NUM_THREADS:'1',OPENBLAS_NUM_THREADS:'1'}});
  let out='',err='';const timer=setTimeout(()=>child.kill('SIGKILL'),20*60*1000);
  child.stdout.on('data',b=>{out+=b;let p;while((p=out.indexOf('\n'))!==-1){const line=out.slice(0,p);out=out.slice(p+1);try{const d=JSON.parse(line);if(d.progress)job.progress=d.progress}catch{}}});
  child.stderr.on('data',b=>{err=(err+b).slice(-3000)});
  child.on('error',e=>{clearTimeout(timer);reject(e)});
  child.on('close',async code=>{clearTimeout(timer);try{const result=JSON.parse(await readFile(path.join(job.dir,'result.json'),'utf8'));if(code||result.error)throw Error(result.error||'İşlem sunucu sınırında durdu. Daha küçük bir belgeyle yeniden deneyin.');resolve(result)}catch(e){console.error('worker',job.action,'exit',code,err.slice(-200));reject(e instanceof Error&&e.message&&!e.message.includes('ENOENT')?e:Error('Bulut işlemi tamamlanamadı. Belgenizi yeniden yükleyip devam edin.'))}});
 });
}
async function drain(){if(active)return;active=true;try{while(queue.length){const item=queue.shift()!;item.job.status='running';try{const result=await item.run();await writeFile(path.join(item.job.dir,'api-result.json'),JSON.stringify(result));item.job.status='done'}catch(e){item.job.status='error';item.job.error=e instanceof Error?e.message:'İşlem tamamlanamadı.'}finally{await rm(path.join(item.job.dir,'input.json'),{force:true})}}}finally{active=false}}
async function schedule(action:string,run:(job:Job)=>Promise<unknown>){
 if(queue.length+(active?1:0)>=6)fail('Bulut sırası dolu. Bir iş tamamlandığında yeniden deneyin.',429);
 if(jobs.size>=60)fail('Geçici belge alanı dolu. Bir süre sonra yeniden deneyin.',429);
 const id=randomBytes(24).toString('hex'),dir=path.join(root,id);await mkdir(dir);
 const job:Job={id,dir,created:Date.now(),status:'queued',progress:'İş sıraya alındı.',action};jobs.set(id,job);queue.push({job,run:()=>run(job)});void drain();return json({id,status:'queued'},202);
}
setInterval(()=>{for(const [id,job] of jobs)if(!['running','queued'].includes(job.status)&&Date.now()-job.created>ttl){jobs.delete(id);void rm(job.dir,{recursive:true,force:true})}},60000).unref();
function findJob(id:string|null){const job=id&&jobs.get(id);if(!job)fail('Bulut oturumu sona ermiş veya sunucu yeniden başlamış. Belgeyi yeniden inceleyin; tarayıcıda kaydedilmiş çeviriler geri yüklenir.',410);return job}
async function pdf(request:Request){
 const form=await request.formData();if(form.get('consent')!=='true')fail('Bulutta işleme onayı gerekli.');
 const action=form.get('action')==='render'?'render':'analyze';
 if(action==='render'){
  const source=findJob(String(form.get('documentId')||''));if(source.action!=='analyze'||source.status!=='done')fail('Belge incelemesi tamamlanmalı.');
  const translations=JSON.parse(String(form.get('translations')||'{}'));if(!translations||typeof translations!=='object'||Array.isArray(translations))fail('Geçersiz çeviri.');
  return schedule('render',async job=>python(job,{action,dir:job.dir,sourceDir:source.dir,translations}));
 }
 const file=form.get('file');if(!(file instanceof File)||file.size>10*1024*1024||file.size<8)fail('En fazla 10 MB geçerli PDF seçin.');
 const bytes=Buffer.from(await file.arrayBuffer());if(bytes.subarray(0,5).toString()!=='%PDF-')fail('Geçerli PDF seçin.');
 const language=String(form.get('language')||'en');if(!['en','de','fr','es'].includes(language))fail('Desteklenen kaynak dili seçin.');
 return schedule('analyze',async job=>{await writeFile(path.join(job.dir,'source.pdf'),bytes);return {...await python(job,{action,dir:job.dir,filename:path.basename(file.name),language,ocr:form.get('ocr')==='always'?'always':'auto',digest:createHash('sha256').update(bytes).digest('hex')}),documentId:job.id}});
}
async function translate(request:Request){
 const d:any=await request.json();if(d.consent!==true)fail('Bulutta işleme onayı gerekli.');
 if(typeof d.source!=='string'||!d.source.trim()||d.source.length>5000||typeof d.glossary!=='string'||d.glossary.length>2000)fail('Geçersiz çeviri alanı.');
 const language=d.sourceLang||'en';if(!['en','de','fr','es'].includes(language))fail('Desteklenen kaynak dili seçin.');
 const prepared=protectPdfText(d.source,d.glossary);
 return schedule('translate',async job=>{
  let bridge=prepared.text;const warnings:string[]=[];
  for(const pair of language==='en'?['en_tr']:[language+'_en','en_tr']){
   const result=await python(job,{action:'translate',dir:job.dir,text:bridge,pair});bridge=result.text;if(result.fragmented)warnings.push('Korunan atıf veya sayılar çevresinde parçalı çeviri kullanıldı; cümle akışını gözden geçirin.');
  }
  const raw=JSON.stringify({translation:bridge,complete:true});const text=readTranslation(raw,d.source,d.glossary);
  return {translation:text,warnings,engine:'Argos / CTranslate2 INT8'};
 });
}
const mime:Record<string,string>={'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.ttf':'font/ttf','.xml':'application/xml','.csl':'application/xml','.txt':'text/plain; charset=utf-8'};
const server=http.createServer(async(req,res)=>{
 try{
  const base='http://'+(req.headers.host||'localhost'),url=new URL(req.url||'/',base);
  const origin=req.headers.origin;if(req.method==='POST'&&origin&&new URL(origin).host!==url.host)fail('Başka bir siteden gelen işlem reddedildi.',403);
  let response:Response;
  if(url.pathname==='/api/health')response=json({ok:true,version:'0.4.0',pdf:'Argos + Tesseract',active:active?1:0,queued:queue.length,languages:['en','de','fr','es']});
  else if(url.pathname==='/api/jobs'&&req.method==='GET'){const job=findJob(url.searchParams.get('id'));response=json({status:job.status,progress:job.progress,position:queue.findIndex(q=>q.job.id===job.id)+1,...(job.status==='done'?{done:true,result:JSON.parse(await readFile(path.join(job.dir,'api-result.json'),'utf8'))}:{}),...(job.error?{error:job.error}:{})},job.status==='error'?422:200)}
  else if(url.pathname.startsWith('/api/')){
   const chunks:Buffer[]=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>12*1024*1024)fail('İstek çok büyük.',413);chunks.push(chunk)}
   const headers=new Headers();for(const[k,v]of Object.entries(req.headers))if(typeof v==='string')headers.set(k,v);
   const request=new Request(url,{method:req.method,headers,...(size?{body:new Uint8Array(Buffer.concat(chunks))}:{})});
   const route=url.pathname;response=route==='/api/pdf'&&req.method==='POST'?await pdf(request):route==='/api/pdf-translate'&&req.method==='POST'?await translate(request):route==='/api/search'&&req.method==='POST'?await search(request):route==='/api/fulltext'&&req.method==='GET'?await fulltext(request):route==='/api/synthesis'&&req.method==='POST'?await synthesis(request):json({error:'İşlem bulunamadı.'},404);
  }else{
   const relative=decodeURIComponent(url.pathname);const file=path.resolve('dist','.'+relative);const directory=path.resolve('dist')+path.sep;if(!file.startsWith(directory))fail('Geçersiz yol.',400);
   let selected=file;try{if(!(await stat(file)).isFile())selected=path.resolve('dist/index.html')}catch{if(path.extname(relative))fail('Dosya bulunamadı.',404);selected=path.resolve('dist/index.html')}
   response=new Response(new Uint8Array(await readFile(selected)),{headers:{'Content-Type':mime[path.extname(selected)]||'application/octet-stream','Cache-Control':relative.startsWith('/assets/')?'public,max-age=31536000,immutable':'no-cache'}});
  }
  res.statusCode=response.status;response.headers.forEach((v,k)=>res.setHeader(k,v));res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','same-origin');res.setHeader('X-Frame-Options','DENY');res.end(Buffer.from(await response.arrayBuffer()));
 }catch(e:any){res.statusCode=e.status||500;res.setHeader('Content-Type','application/json');res.end(JSON.stringify({error:e.status?e.message:'İstek işlenemedi. Yeniden deneyin.'}))}
});
server.requestTimeout=60000;server.listen(Number(process.env.PORT||10000),'0.0.0.0',()=>console.log('Mizan ready'));
