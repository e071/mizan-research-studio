"""Bounded one-job subprocess. OCR and neural translation never share a process."""
import sys,json,pathlib,re,html,base64,hashlib,subprocess,csv,io,math,statistics

def progress(message): print(json.dumps({'progress':message}),flush=True)
def encode(data):return base64.b64encode(data).decode('ascii')
def save(data): (pathlib.Path(JOB['dir'])/'result.json').write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')

def translate():
    import ctranslate2, sentencepiece
    pair=JOB['pair'];root=pathlib.Path('/app/models')/pair
    if pair not in ('en_tr','de_en','fr_en','es_en'):raise ValueError('Desteklenmeyen dil.')
    sp=sentencepiece.SentencePieceProcessor(model_file=str(root/'sentencepiece.model'))
    model=ctranslate2.Translator(str(root/'model'),device='cpu',compute_type='int8',inter_threads=1,intra_threads=1,max_queued_batches=1)
    def decode(text):
        if not re.search(r'[^\W\d_]',text,re.UNICODE):return text
        tokens=sp.encode(text,out_type=str)
        if len(tokens)>180:
            # Keep every character; no silent model input truncation.
            cuts=[m.end() for m in re.finditer(r'[.!?;:]\s+|\s+',text)]
            cuts=[c for c in cuts if 0<c<len(text)]
            if not cuts:raise ValueError('Çok uzun bölünemeyen metin alanı. Alanı kısaltın.')
            cut=min(cuts,key=lambda c:abs(c-len(text)/2))
            return decode(text[:cut])+' '+decode(text[cut:])
        result=model.translate_batch([tokens],beam_size=1,max_batch_size=1,num_hypotheses=1,max_input_length=0,max_decoding_length=384,return_end_token=True,replace_unknowns=True)[0].hypotheses[0]
        if not result or result[-1]!='</s>':raise ValueError('Çeviri motoru metni tamamlayamadı. Daha kısa bir alanla yeniden deneyin.')
        return sp.decode(result[:-1]).strip()
    source=JOB['text'];progress('Açık çeviri modeli işliyor: '+pair.replace('_',' → '))
    output=decode(source)
    expected=re.findall(r'\[\[K\d+\]\]',source)
    def normalized(text):return re.sub(r'(?<!\w)(?:\[{1,2}\s*)?K\s*(\d+)(?:\s*\]{1,2})?(?!\w)',lambda m:'[[K'+m[1]+']]',text)
    output=normalized(output);fragmented=False
    if sorted(re.findall(r'\[\[K\d+\]\]',output))!=sorted(expected):
        # Protected spans never pass through translation in the fallback.
        parts=re.split(r'(\[\[K\d+\]\])',source)
        output=' '.join(p if re.fullmatch(r'\[\[K\d+\]\]',p) else decode(p) for p in parts if p.strip())
        fragmented=True
    save({'text':output,'fragmented':fragmented})

def open_pdf(filename):
    import pymupdf as fitz
    document=fitz.open(filename)
    if document.needs_pass:raise ValueError('Parolalı PDF için önce parolası kaldırılmış bir kopya hazırlayın.')
    if not 0<len(document)<=80:raise ValueError('Bir işlemde en fazla 80 sayfa işlenebilir. Belgeyi bölerek devam edebilirsiniz.')
    for page in document:
        if max(page.rect.width,page.rect.height)>2400:raise ValueError('Sayfa boyutu çok büyük. A4/A3 boyutunda kopya kullanın.')
    return document

def analyze():
    import pymupdf as fitz
    doc=open_pdf(pathlib.Path(JOB['dir'])/'source.pdf');blocks=[];warnings=[]
    for number,page in enumerate(doc):
        progress(f'{number+1}/{len(doc)} sayfa: metin ve OCR inceleniyor')
        # Normalize rotation while preserving appearance, so OCR and native boxes
        # use one coordinate system. Saved normalized copy is also rendered later.
        if page.rotation:page.remove_rotation()
        native=page.get_text('dict',flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)
        chars=sum(len(s['text']) for b in native['blocks'] if b['type']==0 for l in b['lines'] for s in l['spans'])
        use_ocr=JOB['ocr']=='always' or chars<30
        candidates=[]
        if use_ocr:
            scale=min(200/72,math.sqrt(5500000/(page.rect.width*page.rect.height)))
            pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),colorspace=fitz.csRGB,alpha=False)
            png=pathlib.Path(JOB['dir'])/'ocr.png';pix.save(png);width,height=pix.width,pix.height;del pix
            language={'en':'eng','de':'deu','fr':'fra','es':'spa'}[JOB['language']]
            try:
                result=subprocess.run(['tesseract',str(png),'stdout','-l',language,'--oem','1','--psm','3','tsv'],capture_output=True,text=True,timeout=180,check=True)
            finally:png.unlink(missing_ok=True)
            groups={}
            for row in csv.DictReader(io.StringIO(result.stdout),delimiter='\t'):
                word=row.get('text','').strip()
                if row.get('level')!='5' or not word:continue
                key=(row['block_num'],row['par_num'])
                x=float(row['left'])*page.rect.width/width;y=float(row['top'])*page.rect.height/height
                box=[x,y,x+float(row['width'])*page.rect.width/width,y+float(row['height'])*page.rect.height/height]
                groups.setdefault(key,[]).append((word,box,float(row['conf'])))
            for words in groups.values():
                box=fitz.Rect(words[0][1])
                for w in words[1:]:box|=fitz.Rect(w[1])
                candidates.append({'source':' '.join(w[0] for w in words),'box':list(box),'lineBoxes':[w[1] for w in words],'fontSize':statistics.median(w[1][3]-w[1][1] for w in words)*1.1,'color':[0,0,0],'ocr':True,'confidence':round(statistics.mean(w[2] for w in words),1)})
            warnings.append(f'{number+1}. sayfa OCR ile okundu. Sayıları, formülleri ve atıfları orijinalle karşılaştırın; OCR güven puanı doğruluk garantisi değildir.')
        else:
            for block in native['blocks']:
                if block['type']!=0:continue
                spans=[s for line in block['lines'] for s in line['spans'] if s['text'].strip()]
                if not spans:continue
                text='\n'.join(''.join(s['text'] for s in line['spans']) for line in block['lines']).strip()
                text=re.sub(r'(?<=\w)-\n(?=[a-z])','',text).replace('\n',' ')
                color=spans[0]['color']; rgb=[((color>>shift)&255)/255 for shift in (16,8,0)]
                note='Döndürülmüş metin: orijinali korunur.' if any(abs(l['dir'][1])>.01 for l in block['lines']) else None
                candidates.append({'source':text,'box':block['bbox'],'lineBoxes':[s['bbox'] for s in spans],'fontSize':statistics.median(s['size'] for s in spans),'color':rgb,'ocr':False,'confidence':100,'note':note})
        for candidate in candidates:
            text=candidate['source']; box=fitz.Rect(candidate['box']);note=candidate.get('note')
            if len(text)>5000:note='Uzun metin alanı: manuel bölümleme gerekiyor.'
            if not re.search(r'[A-Za-zÀ-ž]{3}',text):note='Sayı, sembol veya kısa etiket: orijinali korunur.'
            if box.is_empty or box.is_infinite:continue
            candidate.update(id=f'p{number+1}-b{len(blocks)+1}',page=number,selected=not bool(note))
            if note:candidate['note']=note
            blocks.append(candidate)
            if len(blocks)>2000:raise ValueError('Belge çok fazla metin alanı içeriyor; daha küçük parçalara bölün.')
    normalized=pathlib.Path(JOB['dir'])/'normalized.pdf';doc.save(normalized,garbage=3,deflate=True)
    plan={'digest':JOB['digest'],'pageCount':len(doc),'blocks':blocks,'warnings':warnings,'filename':JOB['filename'],'language':JOB['language'],'ocr':JOB['ocr']}
    (pathlib.Path(JOB['dir'])/'plan.json').write_text(json.dumps(plan,ensure_ascii=False),encoding='utf-8')
    plan['preview']=encode(doc[0].get_pixmap(matrix=fitz.Matrix(1,1),alpha=False).tobytes('png'));save(plan)

def render():
    import pymupdf as fitz
    root=pathlib.Path(JOB['sourceDir']);plan=json.loads((root/'plan.json').read_text(encoding='utf-8'));doc=open_pdf(root/'normalized.pdf')
    known={b['id']:b for b in plan['blocks']};translations=JOB['translations'];warnings=[];replaced=0
    if len(translations)>2000:raise ValueError('Çok fazla çeviri alanı.')
    for key,text in translations.items():
        if key not in known or not isinstance(text,str) or not text.strip() or len(text)>10000:raise ValueError('Geçersiz çeviri alanı.')
        if known[key].get('note'):raise ValueError('Korunan alan değiştirilemez.')
        if sorted(re.findall(r'\d+(?:[.,]\d+)?',known[key]['source']))!=sorted(re.findall(r'\d+(?:[.,]\d+)?',text)):
            raise ValueError('Sayı kontrolü geçmedi: '+key+'. Çeviriyi orijinal metinle karşılaştırın.')
    archive=fitz.Archive('/app/fonts')
    for number,page in enumerate(doc):
        progress(f'{number+1}/{len(doc)} sayfa: Türkçe metin yerleştiriliyor')
        links=page.get_links();prepared=[]
        for b in plan['blocks']:
            if b['page']!=number or b['id'] not in translations:continue
            rect=fitz.Rect(b['box']);text=translations[b['id']];font=max(7,min(24,b['fontSize']))
            # Extend only within the nearest following block in the same column.
            next_y=min([other['box'][1] for other in plan['blocks'] if other['page']==number and other['id']!=b['id'] and other['box'][1]>=rect.y1-0.1 and other['box'][0]<rect.x1 and other['box'][2]>rect.x0]+[page.rect.height-12])
            rect.y1=min(rect.y1+max(3,font*.45),next_y-1)
            css='@font-face{font-family:noto;src:url(NotoSans-Regular.ttf)} *{font-family:noto} p{margin:0;line-height:1.12;font-size:'+str(font)+'pt;color:rgb('+','.join(str(round(c*255)) for c in b['color'])+')}'
            content='<p>'+html.escape(text)+'</p>'
            scratch=fitz.open();test=scratch.new_page(width=page.rect.width,height=page.rect.height)
            fit=test.insert_htmlbox(rect,content,css=css,archive=archive,scale_low=.60);scratch.close()
            if fit[0]<0:warnings.append(b['id']+': Çeviri alana sığmadı; orijinal korundu.');continue
            if b['ocr']:
                # Scan pixels must actually be removed, not covered by a transparent
                # layer. Refuse non-white/complex backgrounds rather than erase art.
                sample=page.get_pixmap(clip=fitz.Rect(b['box']),matrix=fitz.Matrix(1,1),colorspace=fitz.csGRAY,alpha=False)
                pixels=sample.samples;white=sum(p>235 for p in pixels)/max(1,len(pixels))
                if white<.68:warnings.append(b['id']+': Renkli/karmaşık tarama zemini; görüntü korundu.');continue
            prepared.append((b,rect,content,css))
        for ocr in (False,True):
            relevant=[item for item in prepared if item[0]['ocr']==ocr]
            for b,rect,content,css in relevant:
                for box in b['lineBoxes']:page.add_redact_annot(fitz.Rect(box),fill=(1,1,1) if ocr else False,cross_out=False)
            if relevant:page.apply_redactions(images=2 if ocr else 0,graphics=0,text=0)
        for b,rect,content,css in prepared:
            result=page.insert_htmlbox(rect,content,css=css,archive=archive,scale_low=.60)
            if result[0]<0:raise ValueError('Yerleştirme tutarsızlığı; hatalı PDF sunulmadı.')
            replaced+=1
            if result[1]<.8:warnings.append(b['id']+': Türkçe metin sığması için punto küçültüldü.')
        current={(str(l.get('uri')),tuple(l['from'])) for l in page.get_links()}
        for link in links:
            if link.get('kind')==fitz.LINK_URI and (str(link.get('uri')),tuple(link['from'])) not in current:page.insert_link({k:v for k,v in link.items() if k not in ('xref','id')})
    output=doc.tobytes(garbage=3,deflate=True)
    if len(output)>24*1024*1024:raise ValueError('Çıktı çok büyük; daha küçük bir belgeyle devam edin.')
    save({'pdf':encode(output),'preview':encode(doc[0].get_pixmap(matrix=fitz.Matrix(1,1),alpha=False).tobytes('png')),'replaced':replaced,'warnings':warnings})

JOB=json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))
try:
    {'translate':translate,'analyze':analyze,'render':render}[JOB['action']]()
except Exception as error:
    save({'error':str(error) if isinstance(error,ValueError) else 'Belge işlenemedi. Daha küçük bir belgeyle yeniden deneyin.'})
    import traceback;traceback.print_exc();sys.exit(1)
