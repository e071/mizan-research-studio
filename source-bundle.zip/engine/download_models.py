"""Runs only in the cloud image build. Never downloads models to a user's browser."""
import hashlib, json, pathlib, urllib.request, zipfile, tempfile

ROOT=pathlib.Path('/app/models')
INDEX='https://raw.githubusercontent.com/argosopentech/argospm-index/main/index.json'
index=json.load(urllib.request.urlopen(INDEX,timeout=60))
ROOT.mkdir(parents=True,exist_ok=True)
manifest=[]
for source,target in [('en','tr'),('de','en'),('fr','en'),('es','en')]:
    candidates=[p for p in index if p['from_code']==source and p['to_code']==target and p.get('type','translate')=='translate']
    # EN/TR is the inspected INT8 v1.5 package; other pairs use the official index.
    if source=='en': candidates=[p for p in candidates if p.get('package_version')=='1.5']
    if not candidates: raise RuntimeError('Official model missing: '+source+'_'+target)
    package=candidates[-1]; url=next(u for u in package['links'] if u.startswith('https://'))
    with tempfile.TemporaryDirectory() as temp:
        archive=pathlib.Path(temp)/'model.zip'
        with urllib.request.urlopen(url,timeout=300) as response, archive.open('wb') as output:
            while data:=response.read(1024*1024): output.write(data)
        digest=hashlib.sha256(archive.read_bytes()).hexdigest()
        dest=ROOT/(source+'_'+target); dest.mkdir()
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                parts=pathlib.PurePosixPath(name).parts
                if len(parts)<2 or '..' in parts: continue
                relative=pathlib.Path(*parts[1:])
                # Do not carry Stanza/PyTorch dependencies or models into runtime.
                if parts[1] not in ('model','sentencepiece.model','metadata.json','README.md','LICENSE'):continue
                if name.endswith('/'):continue
                targetfile=dest/relative;targetfile.parent.mkdir(parents=True,exist_ok=True);targetfile.write_bytes(z.read(name))
        if not (dest/'model/model.bin').is_file():raise RuntimeError('Invalid model archive')
        manifest.append({'pair':source+'_'+target,'url':url,'sha256':digest,'package':package.get('package_version'),'license':'MIT / CC0; see third-party notices'})
        print('Installed',source,target,flush=True)
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
