"""CI only: create public synthetic PDFs and use the real HTTP application."""
import os,time,json,pathlib,urllib.request,urllib.error,uuid,base64,re,hashlib
import pymupdf as fitz
BASE=os.environ.get('TEST_URL','http://127.0.0.1:10000');OUT=pathlib.Path('/tmp/test-results');OUT.mkdir(exist_ok=True)
def request(route,data=None,content='application/json'):
    req=urllib.request.Request(BASE+route,data=data,headers={'Content-Type':content} if data else {})
    try:
        with urllib.request.urlopen(req,timeout=150) as r:return json.load(r)
    except urllib.error.HTTPError as e:raise AssertionError(str(e.code)+' '+e.read().decode())
def multipart(values):
    boundary=uuid.uuid4().hex;parts=[]
    for key,value in values.items():
        header=f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"'
        if isinstance(value,bytes):header+='; filename="synthetic.pdf"\r\nContent-Type: application/pdf'
        parts.extend([header.encode()+b'\r\n\r\n',value if isinstance(value,bytes) else str(value).encode(),b'\r\n'])
    return b''.join(parts)+f'--{boundary}--\r\n'.encode(),'multipart/form-data; boundary='+boundary
def job(route,data,content='application/json'):
    start=request(route,data,content)
    for attempt in range(600):
        result=request('/api/jobs?id='+start['id'])
        if result.get('error'):raise AssertionError(result['error'])
        if result.get('done'):return result['result']
        time.sleep(1)
    raise AssertionError('Job timeout')
def translate(source,language='en'):
    return job('/api/pdf-translate',json.dumps({'consent':True,'source':source,'sourceLang':language,'glossary':'self-efficacy = öz yeterlik'}).encode())['translation']
for _ in range(60):
    try:
        if request('/api/health')['ok']:break
    except Exception:time.sleep(1)
else:raise AssertionError('Server did not start')
doc=fitz.open();page=doc.new_page(width=595,height=842)
page.insert_text((45,70),'Teacher wellbeing and classroom support',fontsize=18)
page.insert_textbox(fitz.Rect(45,110,285,215),'This study examined teacher wellbeing. Interviews with 24 teachers showed that peer support reduced stress (Smith, 2024).',fontsize=11)
page.insert_textbox(fitz.Rect(315,110,550,215),'The results suggest an association, not a causal effect. The sample was small. Further research is needed.',fontsize=11)
page.insert_text((45,260),'Results: p < .001; N = 24',fontsize=11)
page.draw_rect(fitz.Rect(45,300,550,400),color=(0,.4,.3));page.draw_line((45,340),(550,340),color=(0,.4,.3));page.draw_line((280,300),(280,400),color=(0,.4,.3))
page.insert_text((60,325),'Group',fontsize=11);page.insert_text((300,325),'Score',fontsize=11)
page.insert_text((60,370),'Teachers',fontsize=11);page.insert_text((300,370),'24',fontsize=11)
page.insert_link({'kind':fitz.LINK_URI,'from':fitz.Rect(45,110,285,215),'uri':'https://example.org/synthetic-study'})
native=doc.tobytes();(OUT/'native-source.pdf').write_bytes(native)
scan=fitz.open();p=scan.new_page(width=595,height=842);p.insert_image(p.rect,stream=page.get_pixmap(matrix=fitz.Matrix(2,2)).tobytes('png'))
scanned=scan.tobytes();(OUT/'scan-source.pdf').write_bytes(scanned)
evidence=[]
for name,data in [('native',native),('scan',scanned)]:
    plan=job('/api/pdf',*multipart({'file':data,'consent':'true','language':'en','ocr':'auto'}))
    assert bool(any(b['ocr'] for b in plan['blocks']))==(name=='scan')
    selected=[b for b in plan['blocks'] if b['selected']];assert len(selected)>=3
    translations={}
    for b in selected:
        translations[b['id']]=translate(b['source']);assert translations[b['id']].strip()
        assert sorted(re.findall(r'\d+(?:[.,]\d+)?',b['source']))==sorted(re.findall(r'\d+(?:[.,]\d+)?',translations[b['id']]))
    result=job('/api/pdf',*multipart({'consent':'true','action':'render','documentId':plan['documentId'],'translations':json.dumps(translations)}))
    output=base64.b64decode(result['pdf']);(OUT/(name+'-translated.pdf')).write_bytes(output)
    (OUT/(name+'-preview.png')).write_bytes(base64.b64decode(result['preview']))
    translated=fitz.open(stream=output,filetype='pdf');text=' '.join(p.get_text() for p in translated)
    assert len(translated)==1 and result['replaced']>=3
    assert re.search('[çğıöşüÇĞİÖŞÜ]',text),'No Turkish glyphs in PDF'
    if name=='native':
        assert 'Teacher wellbeing and classroom support' not in text,'Original native text still present'
        assert translated[0].get_links(),'Link lost'
        assert len(translated[0].get_drawings())>=3,'Table lines lost'
    evidence.append({'kind':name,'selected':len(selected),'replaced':result['replaced'],'translations':translations,'warnings':result['warnings'],'pdfText':text})
for language,source in [('de','Die Studie untersuchte das Wohlbefinden von 24 Lehrkräften.'),('fr','Cette étude examine le bien-être de 24 enseignants.'),('es','Este estudio examina el bienestar de 24 docentes.')]:
    text=translate(source,language);assert '24' in text;evidence.append({'language':language,'source':source,'translation':text})
(OUT/'evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
print(json.dumps({'passed':True,'pdfCases':2,'languages':4,'evidence':evidence},ensure_ascii=False))
