'use client';
import {useEffect,useRef,useState} from 'react';
import {SYNTHESIS_VERSION,evidenceBatches,validateSynthesis,checkpointArticle,type Checkpoint} from '../lib/synthesis';
import {loadCheckpoint,saveCheckpoint} from '../lib/checkpoint-storage';
import type {Paper,Article} from '../lib/research';
export default function SynthesisPanel({papers,topic,article,onArticle,say}:{papers:Paper[];topic:string;article:Article|null;onArticle:(article:Article)=>void;say:(text:string)=>void}){
 const [consent,setConsent]=useState(false),[busy,setBusy]=useState(false),[checkpoint,setCheckpoint]=useState<Checkpoint|null>(null),[status,setStatus]=useState(''),[error,setError]=useState('');
 const stop=useRef(false);const running=useRef(false);
 useEffect(()=>{loadCheckpoint().then(setCheckpoint).catch(()=>setError('Ara taslak kaydı okunamadı.'));return()=>{stop.current=true}},[]);
 const readable=papers.filter(p=>p.selected&&p.abstract.trim()).length;
 async function persist(c:Checkpoint){setCheckpoint({...c,results:[...c.results]});await saveCheckpoint(c)}
 async function start(retry=false){
  if(running.current)return;running.current=true;setBusy(true);setError('');stop.current=false;
  try{const units=evidenceBatches(papers);if(!units.length||!topic.trim())throw Error('Konu ve en az bir özet içeren seçili kaynak gerekli.');
   const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify({version:SYNTHESIS_VERSION,topic,units}))))).map(v=>v.toString(16).padStart(2,'0')).join('');
   let c:Checkpoint=checkpoint?.digest===digest?{...checkpoint,results:[...checkpoint.results]}:{digest,topic,units,next:0,results:[],createdAt:new Date().toISOString()};
   if(c.next>=units.length){say('Bu kaynak seçimi için tüm özet grupları zaten işlendi.');return}
   if(article&&!confirm('Uzak taslak güncellendikçe makale stüdyosundaki metnin yerini alacak. Mevcut düzenlemelerinizi gerekirse Word veya JSON olarak kaydedin. Devam edilsin mi?'))return;
   if(retry)c.jobId=undefined;await persist(c);
   while(c.next<c.units.length&&!stop.current){
    const batch=c.units[c.next];setStatus('Özet grubu '+(c.next+1)+' / '+c.units.length);
    const r=await fetch('/api/synthesis',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({consent,topic:c.topic,units:batch})});const d:any=await r.json();if(!r.ok)throw Error(d.error);
    const result=validateSynthesis(d.text,batch);c.results.push(result);c.next++;c.jobId=undefined;await persist(c);onArticle(checkpointArticle(c));

   }
   setStatus(stop.current?'Duraklatıldı; iş ve tamamlanan özetler kaydedildi.':'Tüm seçili özet grupları işlendi. Atıf dayanaklarını inceleyin.');
  }catch(e){setError(e instanceof Error?e.message:'Uzak taslak tamamlanamadı.')}finally{running.current=false;setBusy(false)}
 }
 return <details className="panel no-print synthesis-panel"><summary>Deneysel uzak sentez <span className="pill">Ücretsiz · Açık kaynak</span></summary><p>Hugging Face üzerindeki apathy-exe/Qwen3.8-27B açık servisi kullanılır (Apache 2.0). Bilgisayarınızda model çalışmaz. Ücretsiz sunucunun kotası, sırası ve kullanılabilirliği değişir. Yalnızca özetlere dayalı bir taslak üretir; PDF çevirmez.</p><label className="consent"><input type="checkbox" checked={consent} disabled={busy} onChange={e=>setConsent(e.target.checked)}/><span>Araştırma konumun ve seçili yayınların başlık / özetlerinin Hugging Face üzerindeki apathy-exe/Qwen3.8-27B servisine gönderilmesini kabul ediyorum. Gizli veya kişisel veri eklemedim. PDF dosyaları ve alınmış tam metinler gönderilmez.</span></label><div className="row"><button className="primary" disabled={!consent||busy||!readable||!topic.trim()} onClick={()=>start()}>{checkpoint&&checkpoint.next<checkpoint.units.length?'Kaydedilen işten devam et':'Deneysel taslak üret'} · {readable} özet</button>{busy&&<button className="secondary" onClick={()=>{stop.current=true;setStatus('Duraklatılıyor…')}}>Duraklat</button>}{error&&<button className="secondary" disabled={!consent||busy} onClick={()=>start(true)}>Bu grubu yeniden dene</button>}</div>{status&&<p role="status">{status}</p>}{error&&<p className="notice warn" role="alert">{error}</p>}{checkpoint&&<small>{checkpoint.next} / {checkpoint.units.length} grup kaydedildi. Sekmeyi açık tutun. Duraklatınca yeni istekler kesilir; devam eden özet tamamlandıktan sonra durulur.</small>}<p className="subtle">Alıntının kaynak metinde bulunması otomatik doğrulanır; yorumun bilimsel doğruluğu bu kontrolle garanti edilemez. Üretim, seçili tüm özet parçalarını sayar; uygun bulunmayanları gerekçesiyle raporlar.</p></details>
}
