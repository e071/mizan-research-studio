import {normalizeDoi,text,decodeAbstract, type Paper, type Provider} from '../../../lib/research';
export const dynamic='force-dynamic';
export async function POST(request:Request){
 try{
 const body:any=await request.json();const {provider,query,cursor='*',from,to,key=''}=body;
 if(!['crossref','europepmc','openalex','semantic','doaj'].includes(provider)||typeof query!=='string'||query.length<2||query.length>1000||typeof cursor!=='string'||cursor.length>10000) return Response.json({error:'Geçerli bir kaynak ve arama sorgusu gerekli.'},{status:400});
 const min=Number(from)||0,max=Number(to)||new Date().getFullYear();if(min<0||max>new Date().getFullYear()||min>max)return Response.json({error:'Yıl aralığını kontrol edin.'},{status:400});
 if(provider==='openalex'&&cursor!=='*'&&!key)return Response.json({error:'OpenAlex derin tarama için ücretsiz API anahtarı istiyor. Bağlantılar bölümünden ekleyip devam edebilirsiniz.'},{status:401});
 if(typeof key!=='string'||key.length>1000)return Response.json({error:'Geçersiz API anahtarı.'},{status:400});
 let url:URL;const headers:Record<string,string>={Accept:'application/json'};
 if(provider==='crossref'){url=new URL('https://api.crossref.org/works');url.search=new URLSearchParams({query,rows:'100',cursor,filter:`type:journal-article,until-pub-date:${max}-12-31`+(min?`,from-pub-date:${min}-01-01`:'')}).toString();}
 else if(provider==='europepmc'){url=new URL('https://www.ebi.ac.uk/europepmc/webservices/rest/search');url.search=new URLSearchParams({query:`(${query}) AND FIRST_PDATE:[${min||1000}-01-01 TO ${max}-12-31]`,format:'json',resultType:'core',pageSize:'100',cursorMark:cursor}).toString();}
 else if(provider==='openalex'){url=new URL('https://api.openalex.org/works');url.search=new URLSearchParams({search:query,per_page:'100',cursor,filter:`to_publication_date:${max}-12-31`+(min?`,from_publication_date:${min}-01-01`:'')}).toString();if(key)headers.Authorization=`Bearer ${key}`;}
 else if(provider==='doaj'){const page=cursor==='*'?1:Number(cursor);if(!Number.isInteger(page)||page<1)return Response.json({error:'Geçersiz sayfa.'},{status:400});url=new URL('https://doaj.org/api/search/articles/'+encodeURIComponent(`(${query}) AND bibjson.year:[${min||1000} TO ${max}]`));url.search=new URLSearchParams({page:String(page),pageSize:'100'}).toString();}
 else {url=new URL('https://api.semanticscholar.org/graph/v1/paper/search/bulk');url.search=new URLSearchParams({query,year:`${min||''}-${max}`,fields:'title,authors,year,abstract,externalIds,venue,journal,url,citationCount'}).toString();if(cursor!=='*')url.searchParams.set('token',cursor);if(key)headers['x-api-key']=key;}
 const response=await fetch(url,{headers,signal:AbortSignal.timeout(25000)});
 if(!response.ok)return Response.json({error:response.status===429?'Kaynağın ücretsiz istek sınırına ulaşıldı. Biraz bekleyip taramaya devam edin.':`Kaynak yanıt vermedi (HTTP ${response.status}). Kayıtlarınız korundu.`},{status:response.status===429?429:502,headers:{'Retry-After':response.headers.get('Retry-After')||'5'}});
 const d:any=await response.json();let records:any[]=[],total=0,next:string|null=null;
 if(provider==='crossref'){records=d.message?.items||[];total=d.message?.['total-results']||0;next=records.length<100?null:d.message?.['next-cursor'];}
 if(provider==='europepmc'){records=d.resultList?.result||[];total=d.hitCount||0;next=records.length<100?null:d.nextCursorMark;}
 if(provider==='openalex'){records=d.results||[];total=d.meta?.count||0;next=records.length<100?null:d.meta?.next_cursor;}
 if(provider==='semantic'){records=d.data||[];total=d.total||0;next=d.token||null;}
 if(provider==='doaj'){records=d.results||[];total=d.total||0;next=d.next?String(Number(d.page||1)+1):null;}
 const now=new Date().toISOString();
 const papers:Paper[]=records.map((w,i):Paper=>{
  let authors:Paper['authors']=[],doi='',title='',year:number|null=null,journal='',volume='',issue='',pages='',abstract='',sourceId='',url='',pmcid='',type='article-journal',citedBy=null;
  const split=(v:string)=>{const parts=v.trim().split(/\s+/);return {family:parts.pop()||'',given:parts.join(' ')}};
  if(provider==='crossref'){authors=(w.author||[]).map((a:any)=>({family:a.family||'',given:a.given||a.name||''}));doi=w.DOI;title=w.title?.[0];year=w.issued?.['date-parts']?.[0]?.[0]||null;journal=w['container-title']?.[0];volume=w.volume;issue=w.issue;pages=w.page;abstract=w.abstract;url=w.URL;sourceId=doi;type=w.type;citedBy=w['is-referenced-by-count']??null;}
  if(provider==='europepmc'){authors=(w.authorList?.author||[]).map((a:any)=>({family:a.lastName||'',given:a.firstName||a.initials||a.fullName||a.collectiveName||''}));doi=w.doi;title=w.title;year=Number(w.pubYear)||null;journal=w.journalInfo?.journal?.title;volume=w.journalInfo?.volume;issue=w.journalInfo?.issue;pages=w.pageInfo;abstract=w.abstractText;pmcid=w.pmcid;sourceId=w.source+':'+w.id;url=`https://europepmc.org/article/${encodeURIComponent(w.source||'MED')}/${encodeURIComponent(w.id)}`;citedBy=w.citedByCount??null;}
  if(provider==='openalex'){authors=(w.authorships||[]).map((a:any)=>split(a.author?.display_name||''));doi=w.doi;title=w.title;year=w.publication_year;journal=w.primary_location?.source?.display_name;volume=w.biblio?.volume;issue=w.biblio?.issue;pages=[w.biblio?.first_page,w.biblio?.last_page].filter(Boolean).join('–');abstract=decodeAbstract(w.abstract_inverted_index);sourceId=w.id;url=w.id;type=w.type;citedBy=w.cited_by_count??null;}
  if(provider==='semantic'){authors=(w.authors||[]).map((a:any)=>split(a.name||''));doi=w.externalIds?.DOI;title=w.title;year=w.year;journal=w.journal?.name||w.venue;volume=w.journal?.volume;pages=w.journal?.pages;abstract=w.abstract;sourceId=w.paperId;url=w.url;citedBy=w.citationCount??null;}
  if(provider==='doaj'){const b=w.bibjson||{};authors=Array.from(new Set<string>((b.author||[]).map((a:any)=>String(a.name||'')))).map(split);doi=b.identifier?.find((v:any)=>v.type?.toLowerCase()==='doi')?.id;title=b.title;year=Number(b.year)||null;journal=b.journal?.title;volume=b.journal?.volume;issue=b.journal?.number;pages=[b.journal?.start_page,b.journal?.end_page].filter(Boolean).join('–');abstract=b.abstract;sourceId=w.id;url='https://doaj.org/article/'+encodeURIComponent(w.id);}
  doi=normalizeDoi(doi);return {id:provider+':'+(sourceId||crypto.randomUUID()),doi,title:text(title),authors,year,journal:text(journal),volume:text(volume),issue:text(issue),pages:text(pages),abstract:text(abstract),url:doi?'https://doi.org/'+doi:(/^https?:\/\//.test(url||'')?url:''),pmcid,sources:[provider],selected:true,screening:'pending',citedBy,retrievedAt:now,type};
 }).filter(p=>p.title);
 return Response.json({papers,total,next:next||null,rawCount:records.length,invalidCount:records.length-papers.length},{headers:{'Cache-Control':'no-store'}});
 }catch(e){return Response.json({error:e instanceof Error&&e.name==='TimeoutError'?'Kaynak zamanında yanıt vermedi. Yeniden deneyebilirsiniz.':'Tarama isteği tamamlanamadı. Bağlantıyı kontrol edip devam edin.'},{status:503});}
}

