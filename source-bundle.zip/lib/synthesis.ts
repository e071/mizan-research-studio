import {z} from 'zod';
import type {Paper,Article,Paragraph} from './research';
export const SYNTHESIS_MODEL='Qwen/Qwen3.8-27B (apathy-exe public Space)';
export const SYNTHESIS_VERSION='qwen38-public-2';
export type EvidenceUnit={id:string;sourceId:string;title:string;text:string};
export type BatchResult={findings:{theme:string;paragraph:Paragraph}[];unused:{unitId:string;reason:string}[]};
export type Checkpoint={digest:string;topic:string;units:EvidenceUnit[][];next:number;results:BatchResult[];jobId?:string;createdAt:string};
export function evidenceBatches(papers:Paper[]){
 const units:EvidenceUnit[]=[];for(const p of papers.filter(p=>p.selected&&p.abstract.trim())){const text=p.abstract.trim();let part=0;for(let pos=0;pos<text.length;){let end=Math.min(pos+2600,text.length);if(end<text.length){const boundary=text.lastIndexOf(' ',end);if(boundary>pos+1300)end=boundary}units.push({id:'u'+units.length,sourceId:p.id,title:p.title.slice(0,600)+(part?' (özet devamı)':''),text:text.slice(pos,end)});pos=end;part++}}
 // One public inference request per evidence unit; completed units are checkpointed.
 // One evidence unit per request keeps the verified free path bounded without dropping sources.
 return units.map(unit=>[unit]);
}
const output=z.object({theme:z.string().max(150),text:z.string().max(1500),quote:z.string().max(600),relevant:z.boolean(),reason:z.string().max(500)}).strict();
const normalize=(s:string)=>s.replace(/\s+/g,' ').trim();
export function validateSynthesis(raw:string,units:EvidenceUnit[]):BatchResult{
 if(units.length!==1)throw Error('Her işlem tam olarak bir özet parçası içermeli.');
 let result:z.infer<typeof output>;
 try{result=output.parse(JSON.parse(raw.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'')))}catch{throw Error('Model beklenen çıktı biçimine uymadı. Bu çıktı taslağa eklenmedi; grubu yeniden deneyebilirsiniz.')}
 const unit=units[0];
 if(!result.relevant){if(!result.reason.trim()||result.text.trim()||result.quote.trim())throw Error('Kaynağı dışlama açıklaması tutarsız. Bu çıktı eklenmedi.');return {findings:[],unused:[{unitId:unit.id,reason:result.reason}]}}
 if(result.quote.trim().length<20||!normalize(unit.text).includes(normalize(result.quote)))throw Error('Modelin dayanak alıntısı gönderilen özette bulunamadı. Bu çıktı taslağa eklenmedi.');
 if(!result.theme.trim()||result.text.trim().length<20)throw Error('Model kullanılabilir bir Türkçe bulgu vermedi. Bu çıktı eklenmedi.');
 return {findings:[{theme:result.theme,paragraph:{text:result.text,sourceIds:[unit.sourceId],evidence:[{sourceId:unit.sourceId,quote:result.quote}]}}],unused:[]};
}
export function checkpointArticle(checkpoint:Checkpoint):Article{
 const themes=new Map<string,{heading:string;paragraphs:Paragraph[]}>();for(const result of checkpoint.results)for(const item of result.findings){const key=item.theme.toLocaleLowerCase('tr').trim();const section=themes.get(key)||{heading:item.theme,paragraphs:[]};section.paragraphs.push(item.paragraph);themes.set(key,section)}
 const readIds=[...new Set(checkpoint.units.slice(0,checkpoint.next).flat().map(u=>u.sourceId))];const allIds=new Set(checkpoint.units.flat().map(u=>u.sourceId));const omitted=checkpoint.results.flatMap(r=>r.unused);
 return {title:checkpoint.topic+' — özetlere dayalı deneysel derleme',sections:[{heading:'Yöntem ve erişilen kapsam',paragraphs:[{text:'Bu taslak, kütüphanede seçilmiş '+allIds.size+' yayının mevcut özetlerinden hazırlanmıştır. '+checkpoint.units.length+' işlem grubunun '+checkpoint.next+' tanesi tamamlanmıştır. Tam metinler bu üretim aşamasında okunmamıştır. Kaynak alıntılarının özetlerde bulunması otomatik denetlenmiştir; yorumların bu alıntılar tarafından desteklenip desteklenmediği araştırmacı değerlendirmesi gerektirir.',sourceIds:[]}]},...themes.values()],readIds,createdAt:checkpoint.createdAt,model:SYNTHESIS_MODEL,limitations:['Bu çıktı nitel araştırmanın veya sistematik derlemenin tamamlanmış hâli değildir. Otomatik tema önerileri ve her yorum araştırmacı tarafından incelenmelidir.','Yalnızca seçili yayınların erişilen özetleri işlenmiştir; özet bulunmayan künyeler ve alınan tam metinler bu uzak motora gönderilmez. Tüm literatürün tarandığı ileri sürülemez.',checkpoint.next<checkpoint.units.length?'Üretim henüz tamamlanmadı.':'Seçili özetlerin tüm parçaları işlendi.',...omitted.map(item=>'Bulguya alınmayan özet parçası '+item.unitId+': '+item.reason)]};
}
