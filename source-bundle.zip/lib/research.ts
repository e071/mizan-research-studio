export type Provider = 'crossref' | 'europepmc' | 'openalex' | 'semantic' | 'doaj';
export const providerNames: Record<Provider,string> = {crossref:'Crossref', europepmc:'Europe PMC', openalex:'OpenAlex', doaj:'DOAJ', semantic:'Semantic Scholar'};
export type Screening = 'pending'|'screen-excluded'|'awaiting-fulltext'|'fulltext-unavailable'|'fulltext-excluded'|'included';
export const screeningNames:Record<Screening,string> = {pending:'Başlık / özet değerlendirmesi bekliyor','screen-excluded':'Başlık / özette dışlandı','awaiting-fulltext':'Tam metin değerlendirmesi bekliyor','fulltext-unavailable':'Tam metne erişilemedi','fulltext-excluded':'Tam metinde dışlandı',included:'Tam metin incelendi, dahil edildi'};
export type Paper = {id:string; doi:string; title:string; authors:{family:string;given:string}[]; year:number|null; journal:string; volume:string; issue:string; pages:string; url:string; abstract:string; fulltext?:string; pmcid?:string; sources:string[]; selected:boolean; exclusion?:string; screening?:Screening; screeningAt?:string; citedBy:number|null; retrievedAt:string; type:string};
export type Scan = {provider:Provider;query:string;cursor:string;status:'ready'|'running'|'complete'|'error';count:number;total:number|null;pages:number;error?:string;invalidCount?:number;duplicateCount?:number;finishedAt?:string};
export type MergeEvent = {incomingId:string;retainedId:string;reason:'doi'|'title-year'|'source-id';key:string;provider?:Provider;query?:string;at:string};
export type Paragraph = {text:string;sourceIds:string[];citationMode?:'parenthetical'|'narrative';evidence?:{sourceId:string;quote:string}[]};
export type Article = {title:string;sections:{heading:string;paragraphs:Paragraph[]}[];readIds:string[];createdAt:string;model:string;limitations:string[]};
export function normalizeDoi(v:string|null|undefined=''){return String(v||'').replace(/^https?:\/\/(?:dx\.)?doi\.org\//i,'').replace(/^doi:\s*/i,'').trim().toLowerCase();}
export function text(v:unknown){return String(v||'').replace(/<[^>]*>/g,' ').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/\s+/g,' ').trim();}
export function safeUrl(value:string=''){try{const url=new URL(value);return ['https:','http:'].includes(url.protocol)?url.href:''}catch{return ''}}
const titleKey=(p:Paper)=>p.title.normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]/gu,'')+'|'+(p.year??'');
export function mergeWithAudit(existing:Paper[],incoming:Paper[],context:{provider?:Provider;query?:string}={}){
 const all=existing.map(p=>({...p,sources:[...p.sources]})),events:MergeEvent[]=[];
 const ids=new Map<string,number>(),dois=new Map<string,number>(),titles=new Map<string,number[]>();
 const index=(p:Paper,i:number)=>{ids.set(p.id,i);if(p.doi)dois.set(normalizeDoi(p.doi),i);const key=titleKey(p);titles.set(key,[...(titles.get(key)||[]),i])};
 all.forEach(index);
 for(const p of incoming){
  const key=titleKey(p),doi=normalizeDoi(p.doi);let i=doi?dois.get(doi):undefined,reason:MergeEvent['reason']='doi';
  if(i===undefined&&ids.has(p.id)){i=ids.get(p.id);reason='source-id'}
  // Different DOIs can identify distinct publications with the same title.
  if(i===undefined&&p.title.length>=12&&p.year!==null){i=(titles.get(key)||[]).find(j=>!doi||!all[j].doi||normalizeDoi(all[j].doi)===doi);reason='title-year'}
  if(i!==undefined){const old=all[i];events.push({incomingId:p.id,retainedId:old.id,reason,key:reason==='doi'?doi:reason==='source-id'?p.id:key,...context,at:new Date().toISOString()});
   old.sources=Array.from(new Set([...old.sources,...p.sources]));if(!old.abstract)old.abstract=p.abstract;if(!old.fulltext)old.fulltext=p.fulltext;
   if(!old.doi&&doi){old.doi=doi;old.url='https://doi.org/'+doi;dois.set(doi,i)}if(!old.pmcid)old.pmcid=p.pmcid;if(!old.authors.length)old.authors=p.authors;
   for(const field of ['journal','volume','issue','pages'] as const)if(!old[field])old[field]=p[field];ids.set(p.id,i);
  }else{const entry={...p,doi,url:safeUrl(p.url),screening:p.screening||'pending' as Screening};index(entry,all.length);all.push(entry)}
 }
 return {papers:all,events};
}
export function mergePapers(existing:Paper[],incoming:Paper[]){return mergeWithAudit(existing,incoming).papers}
export function decodeAbstract(index:Record<string,number[]>|null|undefined){const words:string[]=[];for(const [word,positions]of Object.entries(index||{})){if(!Array.isArray(positions))continue;for(const pos of positions)if(Number.isInteger(pos)&&pos>=0&&pos<50000)words[pos]=word}return words.join(' ').trim()}
export function prismaCounts(papers:Paper[],scans:Scan[],events:MergeEvent[]){
 const count=(stage:Screening)=>papers.filter(p=>(p.screening||'pending')===stage).length;
 const invalid=scans.reduce((n,s)=>n+(s.invalidCount||0),0),identified=scans.reduce((n,s)=>n+s.count,0);
 return {identified,duplicates:events.length,invalid,unique:papers.length,pending:count('pending'),screenExcluded:count('screen-excluded'),fulltextPending:count('awaiting-fulltext'),notRetrieved:count('fulltext-unavailable'),fulltextExcluded:count('fulltext-excluded'),included:count('included'),accounted:identified===events.length+invalid+papers.length};
}
export function toCsl(p:Paper){return {id:p.id,type:p.type==='book'?'book':'article-journal',title:p.title,author:p.authors.filter(a=>a.family||a.given).map(a=>a.family?{family:a.family,given:a.given}:{literal:a.given}),...(p.year?{issued:{'date-parts':[[p.year]]}}:{}),'container-title':p.journal,volume:p.volume,issue:p.issue,page:p.pages,DOI:p.doi,URL:p.doi?undefined:safeUrl(p.url)};}
export function bibtex(papers:Paper[]){const esc=(s:string)=>s.replace(/[{}]/g,'').replace(/\\/g,'').replace(/[\r\n]+/g,' ');return papers.map((p,i)=>'@article{mizan'+(i+1)+',\n  title = {'+esc(p.title)+'},\n  author = {'+p.authors.map(a=>a.family?esc(a.family+', '+a.given):'{'+esc(a.given)+'}').join(' and ')+'},\n  journal = {'+esc(p.journal)+'},\n  year = {'+(p.year||'')+'},\n  volume = {'+esc(p.volume)+'},\n  number = {'+esc(p.issue)+'},\n  pages = {'+esc(p.pages)+'},\n  doi = {'+esc(p.doi)+'},\n  url = {'+esc(safeUrl(p.url))+'}\n}').join('\n\n');}
export function ris(papers:Paper[]){const esc=(s:string)=>s.replace(/[\r\n]+/g,' ');return papers.map(p=>['TY  - JOUR',...p.authors.map(a=>'AU  - '+esc(a.family+', '+a.given)),'TI  - '+esc(p.title),'JO  - '+esc(p.journal),'PY  - '+(p.year||''),'VL  - '+esc(p.volume),'IS  - '+esc(p.issue),'SP  - '+esc(p.pages),'DO  - '+esc(p.doi),'UR  - '+safeUrl(p.url),'ER  - '].join('\r\n')).join('\r\n\r\n');}
