import {Document,Packer,Paragraph,TextRun,HeadingLevel} from 'docx';
import type {Article} from './research';
import {citationParts} from './citation-placement';
function runs(html:string):TextRun[]{const doc=new DOMParser().parseFromString(html,'text/html');const out:TextRun[]=[];function walk(node:Node,italic=false,bold=false){if(node.nodeType===Node.TEXT_NODE){out.push(new TextRun({text:node.textContent||'',italics:italic,bold}));return}for(const child of Array.from(node.childNodes)){const tag=child.nodeName.toLowerCase();walk(child,italic||tag==='i'||tag==='em',bold||tag==='b'||tag==='strong')}}walk(doc.body);return out}
export async function wordDocument(article:Article,formatted:{labels:string[];entries:string[]}){
 let n=0;const children:Paragraph[]=[new Paragraph({text:article.title,heading:HeadingLevel.TITLE})];
 for(const section of article.sections){children.push(new Paragraph({text:section.heading,heading:HeadingLevel.HEADING_1}));for(const p of section.paragraphs){const label=formatted.labels[n++]||'';const citation=runs(label);const parts=citationParts(p.text,!!label,p.citationMode);children.push(new Paragraph({children:[new TextRun(parts.before),...citation,new TextRun(parts.after)],spacing:{line:480,after:0},indent:{firstLine:720}}))}}
 if(article.limitations.length){children.push(new Paragraph({text:'Sınırlılıklar ve kapsam',heading:HeadingLevel.HEADING_1}));children.push(...article.limitations.map(text=>new Paragraph({text,spacing:{line:480}})))}
 children.push(new Paragraph({text:'Kaynakça',heading:HeadingLevel.HEADING_1}));
 children.push(...formatted.entries.map(entry=>new Paragraph({children:runs(entry),indent:{left:720,hanging:720},spacing:{line:480,after:0}})));
 const doc=new Document({title:article.title,styles:{default:{document:{run:{font:'Times New Roman',size:24},paragraph:{spacing:{line:480}}}}},sections:[{properties:{page:{size:{width:11906,height:16838},margin:{top:1440,right:1440,bottom:1440,left:1440}}},children}]});
 return Packer.toBlob(doc);
}
