/** Segments around an already formatted citation, shared by screen, copy and Word. */
export function citationParts(text:string,hasCitation:boolean,mode?:'parenthetical'|'narrative'){
 if(!hasCitation)return {before:text,after:''};
 if(mode==='narrative')return {before:'',after:text?' '+text:''};
 const body=text.trimEnd();
 // Ordinary sentence-final periods follow the citation. Preserve ellipses.
 const movePeriod=body.endsWith('.')&&!body.endsWith('..');
 return {before:(movePeriod?body.slice(0,-1):body)+(body?' ':''),after:movePeriod?'.':''};
}
