import {db} from './storage';
import type {Checkpoint} from './synthesis';
export async function loadCheckpoint():Promise<Checkpoint|null>{const d=await db();return new Promise((resolve,reject)=>{const r=d.transaction('projects').objectStore('projects').get('synthesis');r.onsuccess=()=>{d.close();resolve(r.result||null)};r.onerror=()=>{d.close();reject(r.error)}})}
export async function saveCheckpoint(value:Checkpoint){const d=await db();return new Promise<void>((resolve,reject)=>{const tx=d.transaction('projects','readwrite');tx.objectStore('projects').put(value,'synthesis');tx.oncomplete=()=>{d.close();resolve()};tx.onerror=()=>{d.close();reject(tx.error)}})}
