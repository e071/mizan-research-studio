export type PdfBox=[number,number,number,number];
export type PdfBlock={id:string;page:number;source:string;box:PdfBox;lineBoxes:PdfBox[];fontSize:number;color:number[];selected:boolean;note?:string;ocr?:boolean;confidence?:number};
export type PdfPlan={digest:string;pageCount:number;blocks:PdfBlock[];warnings:string[];filename:string;documentId:string};
export type PdfCheckpoint={digest:string;settings:string;translations:Record<string,string>;jobId?:string;blockId?:string};
export const PDF_MAX_BYTES=10*1024*1024;
