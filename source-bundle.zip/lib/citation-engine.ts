// @ts-ignore citeproc-js implements CSL 1.0.2.
import CSL from 'citeproc';
import {toCsl,type Paper,type Article} from './research';
export function safeCitationHtml(value:string){return value.replace(/<[^>]*>/g,tag=>/^(<\/?(?:i|b|em|strong|sup|sub)>|<div class="csl-entry">|<\/div>)$/.test(tag)?tag:'')}
export function formatCitations(papers:Paper[],article:Article|undefined,style:string,tr:string,en:string){
 const items=new Map(papers.map(p=>[p.id,toCsl(p)]));
 const engine=new CSL.Engine({retrieveLocale:(lang:string)=>lang.startsWith('tr')?tr:en,retrieveItem:(id:string)=>items.get(id)},style,'tr-TR',true);
 engine.setOutputFormat('html');engine.updateItems(papers.map(p=>p.id));
 const labels:string[]=[],prior:[string,number][]=[],positions:number[]=[];
 const clusters=article?article.sections.flatMap(s=>s.paragraphs):papers.map(p=>({sourceIds:[p.id],citationMode:'parenthetical'}));
 clusters.forEach((p,i)=>{labels[i]='';const ids=[...new Set(p.sourceIds)].filter(x=>items.has(x));if(!ids.length)return;
  const id='c'+i;positions.push(i);
  const result=engine.processCitationCluster({citationID:id,citationItems:ids.map(id=>({id})),properties:{noteIndex:0,...(p.citationMode==='narrative'?{mode:'composite',infix:' '}: {})}},prior,[]);
  for(const update of result[1])labels[positions[update[0]]]=safeCitationHtml(update[1]);prior.push([id,0]);
 });
 clusters.forEach((p,i)=>{if(p.citationMode==='narrative')labels[i]=labels[i].replace(/\s+(?:&amp;|&#38;|&)\s+/g,' ve ').replace(/\s{2,}/g,' ')});
 // updateItems also supports bibliography-only export with no citation clusters.
 const result=engine.makeBibliography();const entries:string[]=result?result[1].map(safeCitationHtml):[];
 return {labels,bibliography:entries.join(''),entries};
}
