import {z} from 'zod';
const protectedPattern=/https?:\/\/[^\s]+|\b10\.\d{4,9}\/[^\s]+|\([^()]*\b(?:18|19|20)\d{2}[a-z]?[^()]*\)|(?:\b(?:p|r|F|t|N|n|SD|M|df)|[ηβ])\s*[=<>≤≥]\s*[-+]?(?:\d+(?:[.,]\d+)?|\.\d+)|[-+]?\d+(?:[.,]\d+)?%?/g;
export function protectPdfText(source:string,glossary=''){const values:string[]=[];let text=source.replace(protectedPattern,value=>{const citation=value.startsWith('(')&&value.endsWith(')');const id=values.push(value)-1;return (citation?'(':'')+'[[K'+id+']]'+(citation?')':'')});const terms=glossary.split('\n').map(line=>line.split('=').map(s=>s.trim())).filter(parts=>parts.length===2&&parts[0]&&parts[1]).sort((a,b)=>b[0].length-a[0].length);for(const [term,target] of terms){if(term.includes('[[')||target.includes('[['))continue;const escaped=term.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');text=text.replace(new RegExp('(?<!\\p{L})'+escaped+'(?!\\p{L})','giu'),()=>{const id=values.push(target)-1;return '[[K'+id+']]'})}return {text,values}}
export function readTranslation(raw:string,source:string,glossary=''){
 let parsed:{translation:string;complete:boolean};try{parsed=z.object({translation:z.string().min(1).max(5000),complete:z.literal(true)}).strict().parse(JSON.parse(raw.trim().replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,'')))}catch{throw Error('Çeviri yarım veya beklenen biçimde değil. Bu alan kaydedilmedi; yeniden deneyin.')}
 const {values}=protectPdfText(source,glossary);let text=parsed.translation;
 // MADLAD can remove marker brackets while preserving the exact K-number label.
 // Normalize only standalone labels; missing, repeated or unknown IDs still fail closed.
 text=text.replace(/(?<![\p{L}\p{N}])(?:\[{1,2}\s*)?K\s*(\d+)(?:\s*\]{1,2})?(?![\p{L}\p{N}])/gu,(_match,id)=>'[[K'+id+']]');
 values.forEach((value,index)=>{const marker='[[K'+index+']]';if(text.split(marker).length!==2)throw Error('Sayı / atıf koruma kontrolü geçmedi. Bu alan kaydedilmedi.');text=value.startsWith('(')&&value.endsWith(')')&&text.includes('('+marker+')')?text.replace('('+marker+')',value):text.replace(marker,value)});
 if(/\[\[K\d+\]\]/.test(text))throw Error('Çeviride bilinmeyen koruma işareti var.');
 const originalNumbers=(source.match(/\d+(?:[.,]\d+)?/g)||[]).sort().join('|');const translatedNumbers=(text.match(/\d+(?:[.,]\d+)?/g)||[]).sort().join('|');if(originalNumbers!==translatedNumbers)throw Error('Çeviri sayısal içeriği değiştirdi. Bu alan kaydedilmedi.');return text;
}
