import {db} from './storage';
import type {PdfCheckpoint} from './pdf-types';
export async function loadPdfCheckpoint():Promise<PdfCheckpoint|null>{const d=await db();return new Promise((resolve,reject)=>{const r=d.transaction('projects').objectStore('projects').get('pdf');r.onsuccess=()=>{d.close();resolve(r.result||null)};r.onerror=()=>{d.close();reject(r.error)}})}
export async function savePdfCheckpoint(value:PdfCheckpoint){const d=await db();return new Promise<void>((resolve,reject)=>{const t=d.transaction('projects','readwrite');t.objectStore('projects').put(value,'pdf');t.oncomplete=()=>{d.close();resolve()};t.onerror=()=>{d.close();reject(t.error)}})}
