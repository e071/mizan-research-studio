import {formatCitations} from './citation-engine';
import type {Paper,Article} from './research';
let resources:Promise<string[]>|null=null;
export async function citations(papers:Paper[],article?:Article){
 resources??=Promise.all(['/csl/apa.csl','/csl/locales-tr-TR.xml','/csl/locales-en-US.xml'].map(async path=>{const r=await fetch(path);if(!r.ok)throw Error('CSL dosyası yüklenemedi');return r.text()})).catch(error=>{resources=null;throw error});
 const [style,tr,en]=await resources;return formatCitations(papers,article,style,tr,en);
}
